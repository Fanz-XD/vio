const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const finePointer = matchMedia('(hover: hover) and (pointer: fine)').matches;
const WA_NUMBER = '6281380922021';   // WhatsApp Jaya Bakery (format internasional, tanpa +)


// scroll: navbar, progress bar, back-to-top, active link (dibatasi per frame)
const nav = $('#navbar'), progress = $('#progress'), toTop = $('#toTop');
const links = $$('.navlinks a');
const sections = $$('section[id]');
let ticking = false;
function onScroll(){
  const y = window.scrollY, max = document.documentElement.scrollHeight - innerHeight;
  nav.classList.toggle('scrolled', y>60);
  toTop.classList.toggle('show', y>500);
  progress.style.transform = 'scaleX(' + (max>0 ? Math.min(1,y/max) : 0) + ')';
  let cur='';
  sections.forEach(s=>{ if(y+90 >= s.offsetTop) cur = s.id; });
  links.forEach(l=>l.classList.toggle('active', l.getAttribute('href')==='#'+cur));
  ticking = false;
}
addEventListener('scroll',()=>{ if(!ticking){ ticking=true; requestAnimationFrame(onScroll); } },{passive:true});
onScroll();

// burger menu
const burger = $('#burger'), navlinks = $('#navlinks');
function setMenu(open){
  navlinks.classList.toggle('open', open);
  burger.setAttribute('aria-expanded', open);
  burger.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
  burger.textContent = open ? '✕' : '☰';
}
burger.addEventListener('click',()=>setMenu(!navlinks.classList.contains('open')));
links.forEach(l=>l.addEventListener('click',()=>setMenu(false)));

// scroll reveal
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('visible'); } });
},{threshold:.15});
$$('.reveal').forEach(el=>observer.observe(el));

// counters
const counterObs = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      const el = e.target, target = +el.dataset.target;
      let cur = 0; const step = Math.max(1, target/60);
      const tick = ()=>{ cur += step; if(cur < target){ el.textContent = Math.floor(cur); requestAnimationFrame(tick);} else { el.textContent = target; } };
      tick();
      counterObs.unobserve(el);
    }
  });
},{threshold:.5});
$$('.counter').forEach(c=>counterObs.observe(c));


// pesan produk: varian + jumlah → estimasi total → pesan WhatsApp siap kirim
const rupiah = n => 'Rp ' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
$$('.order').forEach(box=>{
  const sel = $('select',box), out = $('output',box), totalEl = $('.total-val',box), wa = $('.wa-order',box);
  let qty = 1;
  function update(animate){
    const opt = sel ? sel.selectedOptions[0] : null;
    const price = +(opt ? opt.dataset.price : box.dataset.price);
    const label = opt ? opt.dataset.label : '';
    const total = price * qty;
    out.textContent = qty;
    totalEl.textContent = rupiah(total);
    if(animate){ totalEl.classList.remove('pop'); void totalEl.offsetWidth; totalEl.classList.add('pop'); }
    const msg = 'Halo Jaya Bakery, saya ingin memesan:\n' +
      '• ' + box.dataset.product + (label ? ' — ' + label : '') + ' × ' + qty + '\n' +
      'Estimasi total: ' + rupiah(total) + '\n\nTerima kasih!';
    wa.href = 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(msg);
  }
  $$('.qty button',box).forEach(b=>b.addEventListener('click',()=>{
    qty = Math.min(99, Math.max(1, qty + (+b.dataset.step)));
    update(true);
  }));
  if(sel) sel.addEventListener('change',()=>update(true));
  update(false);
});

// lightbox foto produk
const lb = $('#lightbox'), lbImg = $('#lbImg'), lbCap = $('#lbCap'), lbClose = $('#lbClose');
let lbTrigger = null;
function openLB(fig){
  const img = $('img',fig);
  lbImg.src = img.src; lbImg.alt = img.alt; lbCap.textContent = img.alt;
  lbTrigger = fig; lb.hidden = false;
  requestAnimationFrame(()=>lb.classList.add('open'));
  document.body.style.overflow = 'hidden';
  lbClose.focus();
}
function closeLB(){
  lb.classList.remove('open');
  document.body.style.overflow = '';
  setTimeout(()=>{ lb.hidden = true; lbImg.removeAttribute('src'); }, reduceMotion ? 0 : 300);
  if(lbTrigger) lbTrigger.focus();
}
$$('.p-visual').forEach(fig=>{
  fig.addEventListener('click',()=>openLB(fig));
  fig.addEventListener('keydown',e=>{ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); openLB(fig); } });
});
lb.addEventListener('click',e=>{ if(e.target !== lbImg) closeLB(); });
lb.addEventListener('keydown',e=>{ if(e.key==='Tab'){ e.preventDefault(); lbClose.focus(); } });

// speed-dial kontak
const dial = $('#dial'), dialBtn = $('#dialBtn');
function setDial(open){
  dial.classList.toggle('open', open);
  dialBtn.setAttribute('aria-expanded', open);
}
dialBtn.addEventListener('click',e=>{ e.stopPropagation(); setDial(!dial.classList.contains('open')); });
document.addEventListener('click',e=>{ if(!dial.contains(e.target)) setDial(false); });

// Escape menutup panel yang sedang terbuka
document.addEventListener('keydown',e=>{
  if(e.key !== 'Escape') return;
  if(!lb.hidden) closeLB();
  setDial(false); setMenu(false);
});

// back to top
toTop.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

